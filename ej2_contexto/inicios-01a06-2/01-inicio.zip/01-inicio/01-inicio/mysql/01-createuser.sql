CREATE USER 'ejercicio2'@'%' IDENTIFIED BY 'ejercicio2';
GRANT ALL PRIVILEGES ON `ejercicio2`.* TO 'ejercicio2'@'%';

CREATE USER 'ejercicio2'@'localhost' IDENTIFIED BY 'ejercicio2';
GRANT ALL PRIVILEGES ON `ejercicio2`.* TO 'ejercicio2'@'localhost';